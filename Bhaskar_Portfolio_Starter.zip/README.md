# Bhaskar Portfolio Starter

Open index.html in your browser.

Next improvements:
- Dark/Light mode
- Typing animation
- Timeline
- Project gallery
- Contact form backend
